import sys
try:
  import tweepy
except:
  print("Please open the Shell and run 'social_install' script")
  sys.exit(1)

from wyliodrin import *

from threading import Timer

tweet = None

twitter_key = '0GqbRBgCBezLppVJ6qNtIRTBe'
twitter_secret = 'DDTl0IeCDrU63xLsivj9pcsuDC92GI6kRZZ0RT11Ao8lSBjHsg'
twitter_token = '710799654393405441-QxlHDhnMqUqP3AsWvhuzypLKw62CzIu'
twitter_secretToken = 'Byxww5dZeUUuopvi7ShlMc6OlnfY2bWS3NZ7Xya45um1W'

def twitterFunction(cKey, cSecret, aToken, aTSecret):
  auth = tweepy.OAuthHandler(cKey, cSecret)
  auth.set_access_token(aToken, aTSecret)
  twitter_tweet = tweepy.API(auth)
  return twitter_tweet

def twitterUserTimelineFunction(user):
  twitter_tweet = twitterFunction(twitter_key, twitter_secret, twitter_token, twitter_secretToken)
  if user == 'myself':
    public_tweets =twitter_tweet.user_timeline()
  else:
    public_tweets =twitter_tweet.user_timeline(user)
  tweetArray = []
  for tweetTimeline in public_tweets:
    tweetArray.append(tweetTimeline.text)
  return tweetArray

pinMode (9, 1)


print('twitter setup')
print('waiting for tweets')
def loopCode():
  global tweet
  print('looking for tweets')
  tweet = (twitterUserTimelineFunction('myself'))[0]
  if tweet.find('on') + 1 > 0:
    digitalWrite (9, 1)
    print('Device is on')
  elif tweet.find('off') + 1 > 0:
    digitalWrite (9, 0)
    print('Device is off')
  print(tweet)
  Timer(3, loopCode).start()
loopCode()
twitter_tweet = twitterFunction(twitter_key, twitter_secret, twitter_token, twitter_secretToken)
twitter_tweet.update_status(str('Thank you for controlling the lamp'))
