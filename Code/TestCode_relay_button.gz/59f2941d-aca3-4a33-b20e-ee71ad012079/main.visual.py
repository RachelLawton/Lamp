from wyliodrin import *

pinMode (10, 0)

pinMode (9, 1)


if (digitalRead (10) == 1) == True:
  digitalWrite (9, 1)
  print('The device is on')
if (digitalRead (10) == 0) == True:
  digitalWrite (9, 0)
  print('The device is off')
