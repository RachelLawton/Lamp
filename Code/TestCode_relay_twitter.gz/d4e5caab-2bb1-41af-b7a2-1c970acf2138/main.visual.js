var SysTwitter = require('sys');
var twitterVar = require('twitter-ng');
if (!twitterVar){
  console.log("Please open the Shell and run 'social_install' script");
  SysTwitter.exit(1);}


twitter_key = '2Y2TTqQ9ShmBxzKmwzzEMDWQ8';
twitter_secret = 'RpXqOcOH2VfurKvauZi9J9YxyZEAQqHWp6LixkoWeplPwapoYu';
twitter_token = '2685525938-KKQE8p3gBWRcroAfVGiBxNGvQHBnMu1knyO4Rgn';
twitter_secretToken = 'Gl9lXn8LsDQjJF08c12tDIFilLFtrqNYTy3xgpXbw2OP4';
var twitterObject = new twitterVar({
consumer_key: twitter_key,
consumer_secret: twitter_secret,
access_token_key: twitter_token,
access_token_secret: twitter_secretToken
});


var wyliodrin = require("wyliodrin");



wyliodrin.delay (1000);
twitterObject.updateStatus('Your device is off',function(data) {});

function loopCode()
{
}
setInterval(loopCode, 90000);
